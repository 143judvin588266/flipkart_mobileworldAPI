
exports.errors = {
    API_MESSAGE_CREATE_FAILED: "Create Movie Details Request Failed"
}