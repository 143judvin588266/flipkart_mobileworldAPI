// /**
//  * Setup the Database URL
//  */

const DB_USER = "judvin";
const DB_PASSWORD = "judvin";
const DB_NAME = "flipkartMobileworld";
const CLUSTER_HOST = "apidemo.jymaw.mongodb.net";

//DB Connection String

exports.DB_URI = `mongodb+srv://${DB_USER}:${DB_PASSWORD}@${CLUSTER_HOST}/${DB_NAME}?retryWrites=true&w=majority`;

