/**
 * 
 * Model for the MoviesHub Package
 */

var settings = require('../db/settings')


var MoviesSchema = settings.mongoose.Schema(
    {
        name: { type: String, required: [true, 'name is needed'] },
        brand: { type: String, required: true },
        color: { type: String, required: true },
        price:{type:Number, required},
        ram: { type: String, enum: ['2gb', '3gb', '4gb', '6gb', '8gb'] },
        camera: { front: { type: String, required: true }, rear: { type: String, required: true } },
        pictures: { type: [String] },
         
    }
);

// Export the model
exports.Mobileworld = settings.mongoose.model('flipkartMobileworld', Mobileworld)