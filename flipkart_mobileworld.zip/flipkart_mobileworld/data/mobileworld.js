
exports.SingleRow = {
    "name": "j7 prime",
    "brand": "Samsung",
    "color": "Black",
    "price":12000,
    "Ram": "2gb",
    "camera": {
        "front": 12,
        "rating": 20,
    },
    "pictures": ["https://www.google.com/search?q=j7+prime&sxsrf=ALeKk00mH6rxPYdW54v6tlh6F56Fjpq5vw:1609140396550&source=lnms&tbm=isch&sa=X&ved=2ahUKEwj3j-uNk_DtAhXMc30KHY3BAlIQ_AUoAnoECBMQBA&biw=1366&bih=568#imgrc=uE6UvDZLBt8dZM"],
    
}

exports.MultipleRows = [
    {
        "name": "j7 prime",
        "brand": "Samsung",
        "color": "Black",
        "price":12000,
        "Ram": "2gb",
        "camera": {
            "front": 12,
            "rating": 20,
        },
        "pictures": ["https://www.google.com/search?q=j7+prime&sxsrf=ALeKk00mH6rxPYdW54v6tlh6F56Fjpq5vw:1609140396550&source=lnms&tbm=isch&sa=X&ved=2ahUKEwj3j-uNk_DtAhXMc30KHY3BAlIQ_AUoAnoECBMQBA&biw=1366&bih=568#imgrc=uE6UvDZLBt8dZM"],
    },
    {
        
            "name": "j7 prime",
            "brand": "Samsung",
            "color": "Black",
            "price":12000,
            "Ram": "2gb",
            "camera": {
                "front": 12,
                "rating": 20,
            },
            "pictures": ["https://www.google.com/search?q=j7+prime&sxsrf=ALeKk00mH6rxPYdW54v6tlh6F56Fjpq5vw:1609140396550&source=lnms&tbm=isch&sa=X&ved=2ahUKEwj3j-uNk_DtAhXMc30KHY3BAlIQ_AUoAnoECBMQBA&biw=1366&bih=568#imgrc=uE6UvDZLBt8dZM"],
         } ,
    
        {
            "name": "j7 prime",
            "brand": "Samsung",
            "color": "Black",
            "price":12000,
            "Ram": "2gb",
            "camera": {
                "front": 12,
                "rating": 20,
            },
            "pictures": ["https://www.google.com/search?q=j7+prime&sxsrf=ALeKk00mH6rxPYdW54v6tlh6F56Fjpq5vw:1609140396550&source=lnms&tbm=isch&sa=X&ved=2ahUKEwj3j-uNk_DtAhXMc30KHY3BAlIQ_AUoAnoECBMQBA&biw=1366&bih=568#imgrc=uE6UvDZLBt8dZM"],
            
    }
]
